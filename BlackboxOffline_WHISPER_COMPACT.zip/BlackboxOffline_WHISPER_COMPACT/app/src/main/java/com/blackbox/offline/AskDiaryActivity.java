package com.blackbox.offline;

import android.app.*;
import android.graphics.Color;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Local question UI. It never sends journal text over the network. */
public class AskDiaryActivity extends Activity {
 private EditText question; private TextView answer;
 @Override public void onCreate(Bundle b){super.onCreate(b);build();}
 private void build(){ScrollView s=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(22),dp(25),dp(22),dp(30));root.setBackgroundColor(Color.rgb(11,12,13));s.addView(root);setContentView(s);
  Button back=button("‹ Назад",Color.rgb(46,49,51));root.addView(back);back.setOnClickListener(v->finish());TextView h=text("Спросить дневник",26,Color.rgb(247,243,238));h.setPadding(0,dp(22),0,dp(8));root.addView(h);root.addView(text("Вопрос и записи обрабатываются только на устройстве после подключения локального AI-движка.",14,Color.rgb(183,177,168)));
  question=new EditText(this);question.setHint("Например: Что я говорил сегодня о работе?");question.setHintTextColor(Color.rgb(140,134,126));question.setTextColor(Color.WHITE);question.setSingleLine(false);question.setMinLines(3);question.setBackgroundColor(Color.rgb(23,25,27));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(18),0,dp(12));root.addView(question,p);Button ask=button("Спросить локальный дневник",Color.rgb(244,119,33));root.addView(ask);answer=text("",16,Color.rgb(247,243,238));answer.setPadding(0,dp(22),0,0);root.addView(answer);ask.setOnClickListener(v->ask());}
 private void ask(){String q=question.getText().toString().trim();if(q.isEmpty()){question.setError("Введи вопрос");return;}ArrayList<Entry> list=new EntryStore(this).all();StringBuilder context=new StringBuilder();for(Entry e:list)if(!e.transcript.isEmpty())context.append(e.created).append(": ").append(e.transcript).append('\n');if(context.length()==0){answer.setText("Пока нет расшифрованных записей для поиска.");return;}try{answer.setText(new LocalAiEngine(this).answer(q,context.toString()));}catch(Exception e){answer.setText("Локальный AI пока не готов: импортируй модели и добавь нативный AI-движок в APK.");}}
 private TextView text(String x,int z,int c){TextView v=new TextView(this);v.setText(x);v.setTextSize(z);v.setTextColor(c);return v;}private Button button(String x,int c){Button b=new Button(this);b.setText(x);b.setTextSize(16);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundColor(c);return b;}private int dp(int n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}
}
