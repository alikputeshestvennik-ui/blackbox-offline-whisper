package com.blackbox.offline;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

/** Local-only Blackbox journal. It intentionally declares no INTERNET permission. */
public class MainActivity extends Activity {
    private static final int MIC_REQUEST=44;
    private static final int ORANGE=Color.rgb(244,119,33), BG=Color.rgb(11,12,13), CARD=Color.rgb(23,25,27), TEXT=Color.rgb(247,243,238), MUTED=Color.rgb(183,177,168);
    private LinearLayout root, content; private TextView title, subtitle; private Button recordButton;
    private MediaRecorder recorder; private MediaPlayer player; private File recordingFile; private long startedAt; private boolean recording=false;
    private final Handler handler=new Handler(Looper.getMainLooper()); private Runnable ticker;
    private EntryStore store; private LocalAiEngine ai;

    @Override public void onCreate(Bundle b){super.onCreate(b);store=new EntryStore(this);ai=new LocalAiEngine(this); showHome();}
    private void base(String heading,String sub){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(22),dp(20),dp(30));root.setBackgroundColor(BG);scroll.addView(root);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL); ImageView mark=new ImageView(this);mark.setImageResource(com.blackbox.offline.R.drawable.blackbox_mark);head.addView(mark,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);words.setPadding(dp(12),0,0,0);title=label(heading,27,TEXT);subtitle=label(sub,13,MUTED);words.addView(title);words.addView(subtitle);head.addView(words);root.addView(head);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,dp(22),0,0);root.addView(content);setContentView(scroll);
    }
    private void showHome(){base("Blackbox","Локальный аудиодневник · без интернета");
        TextView privacy=label("Запись включается только вручную. Аудио, тексты и ответы остаются на этом телефоне.",15,MUTED);privacy.setPadding(dp(16),dp(15),dp(16),dp(15));privacy.setBackground(card());content.addView(privacy,wide());
        recordButton=button("●  Начать запись",ORANGE); LinearLayout.LayoutParams rp=wide();rp.setMargins(0,dp(18),0,0);content.addView(recordButton,rp);recordButton.setOnClickListener(v->toggleRecording());
        Button history=button("История записей",CARD); addSpace(10);content.addView(history,wide());history.setOnClickListener(v->showHistory());
        Button ask=button("Спросить Blackbox",CARD);addSpace(10);content.addView(ask,wide());ask.setOnClickListener(v->showAsk());
        Button models=button(ai.ready()?"Локальный AI готов":"Настроить локальный AI",CARD);addSpace(10);content.addView(models,wide());models.setOnClickListener(v->showModels());
        TextView footer=label("Микрофон не используется в фоне. При сворачивании приложения запись будет остановлена.",13,MUTED);footer.setPadding(0,dp(24),0,0);content.addView(footer);
    }
    private void toggleRecording(){if(recording)stopRecording();else if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC_REQUEST);else startRecording();}
    private void startRecording(){try{
        File dir=new File(getExternalFilesDir(null),"audio");if(!dir.exists())dir.mkdirs();String id=UUID.randomUUID().toString();recordingFile=new File(dir,id+".m4a");
        recorder=new MediaRecorder();recorder.setAudioSource(MediaRecorder.AudioSource.MIC);recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);recorder.setAudioEncodingBitRate(128000);recorder.setAudioSamplingRate(44100);recorder.setOutputFile(recordingFile.getAbsolutePath());recorder.prepare();recorder.start();
        recording=true;startedAt=System.currentTimeMillis();recordButton.setBackgroundColor(Color.rgb(198,61,33)); tick();
    }catch(Exception e){toast("Не удалось начать запись: "+e.getMessage()); releaseRecorder();}}
    private void tick(){if(!recording)return;long sec=(System.currentTimeMillis()-startedAt)/1000;recordButton.setText("■  Остановить · "+String.format(Locale.getDefault(),"%02d:%02d",sec/60,sec%60));ticker=()->tick();handler.postDelayed(ticker,500);}
    private void stopRecording(){if(!recording)return;long duration=(System.currentTimeMillis()-startedAt)/1000;try{recorder.stop();}catch(Exception ignored){}releaseRecorder();recording=false;if(ticker!=null)handler.removeCallbacks(ticker);
        String created=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date());store.add(new Entry(recordingFile.getName().replace(".m4a",""),recordingFile.getAbsolutePath(),created,duration,"",""));toast("Запись сохранена локально");showHome();}
    private void showHistory(){base("История","Аудио и заметки на устройстве");ArrayList<Entry> all=store.all();if(all.isEmpty()){content.addView(label("Пока нет записей. Начни запись на главном экране.",16,MUTED));return;}for(Entry e:all)addEntryCard(e);}
    private void addEntryCard(final Entry e){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(16),dp(15),dp(16),dp(14));box.setBackground(card());TextView d=label(e.created+"  ·  "+formatDuration(e.duration),17,TEXT);box.addView(d);TextView details=label(e.summary.isEmpty()?(e.transcript.isEmpty()?"Аудиозапись без расшифровки":"Есть расшифровка"):e.summary,14,MUTED);details.setPadding(0,dp(8),0,dp(10));box.addView(details);
        LinearLayout row=new LinearLayout(this);Button play=small("▶ Слушать");Button transcribe=small(e.transcript.isEmpty()?"Расшифровать":"Саммари");Button del=small("Удалить");row.addView(play);row.addView(transcribe);row.addView(del);box.addView(row);play.setOnClickListener(v->play(e));transcribe.setOnClickListener(v->processEntry(e));del.setOnClickListener(v->confirmDelete(e));LinearLayout.LayoutParams p=wide();p.setMargins(0,0,0,dp(12));content.addView(box,p);}
    private void processEntry(Entry e){try{if(e.transcript.isEmpty()){e.transcript=ai.transcribe(e.path);replace(e);toast("Расшифровка готова");}else{e.summary=ai.summarize(e.transcript);replace(e);toast("Саммари готово");}showHistory();}catch(Exception x){showModels();toast(x.getMessage());}}
    private void play(Entry e){try{if(player!=null){player.release();}player=new MediaPlayer();player.setDataSource(e.path);player.prepare();player.start();toast("Воспроизведение");}catch(Exception x){toast("Не удалось воспроизвести запись");}}
    private void confirmDelete(Entry e){new AlertDialog.Builder(this).setTitle("Удалить запись?").setMessage("Аудио, расшифровка и саммари будут удалены с телефона.").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{if(player!=null)player.stop();new File(e.path).delete();store.delete(e.id);showHistory();}).show();}
    private void replace(Entry updated){ArrayList<Entry> a=store.all();for(int i=0;i<a.size();i++)if(a.get(i).id.equals(updated.id))a.set(i,updated);store.save(a);}
    private void showAsk(){base("Спросить Blackbox","Ответ строится только по локальным записям");final EditText q=new EditText(this);q.setHint("Например: Как прошёл вечер 14 мая?");q.setTextColor(TEXT);q.setHintTextColor(MUTED);q.setTextSize(17);q.setSingleLine(false);q.setPadding(dp(15),dp(14),dp(15),dp(14));q.setBackground(card());content.addView(q,wide());Button send=button("Спросить",ORANGE);addSpace(12);content.addView(send,wide());TextView answer=label("",16,TEXT);answer.setPadding(0,dp(20),0,0);content.addView(answer);send.setOnClickListener(v->{try{String context=buildContext(q.getText().toString());answer.setText(ai.answer(q.getText().toString(),context));}catch(Exception e){answer.setText("AI ещё не установлен. Открой «Настроить локальный AI» на главном экране.");}});}
    private String buildContext(String question){StringBuilder s=new StringBuilder();for(Entry e:store.all())if(!e.transcript.isEmpty())s.append("Дата: ").append(e.created).append("\n").append(e.transcript).append("\nСаммари: ").append(e.summary).append("\n\n");return s.length()==0?"Нет расшифрованных записей.":s.toString();}
    private void showModels(){base("Локальный AI","Модели остаются на телефоне");TextView info=label("Чтобы включить реальную офлайн-расшифровку и саммари, помести файлы моделей и нативный модуль в указанные места. Приложение не имеет разрешения INTERNET и ничего не скачивает само.\n\nПапка моделей:\n"+ai.folder().getAbsolutePath()+"\n\nНужны файлы:\n• whisper-small.bin\n• qwen2.5-3b-q4.gguf\n• libblackbox_ai.so (arm64-v8a, включается в app/src/main/jniLibs/arm64-v8a при сборке)\n\nСтатус: "+(ai.ready()?"готово":"модели/нативный модуль не найдены"),15,MUTED);info.setPadding(dp(16),dp(16),dp(16),dp(16));info.setBackground(card());content.addView(info,wide());}
    private void releaseRecorder(){if(recorder!=null){recorder.release();recorder=null;}}
    @Override public void onRequestPermissionsResult(int r,String[]p,int[]g){super.onRequestPermissionsResult(r,p,g);if(r==MIC_REQUEST&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startRecording();else toast("Без доступа к микрофону запись невозможна.");}
    @Override protected void onPause(){super.onPause();if(recording)stopRecording();}
    @Override protected void onDestroy(){releaseRecorder();if(player!=null)player.release();super.onDestroy();}
    private TextView label(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);return v;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextSize(17);b.setTextColor(TEXT);b.setAllCaps(false);b.setBackgroundColor(color);b.setPadding(0,dp(12),0,dp(12));return b;}
    private Button small(String s){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setTextColor(TEXT);b.setAllCaps(false);b.setBackgroundColor(Color.rgb(46,49,51));return b;}
    private GradientDrawable card(){GradientDrawable g=new GradientDrawable();g.setColor(CARD);g.setCornerRadius(dp(18));return g;}
    private LinearLayout.LayoutParams wide(){return new LinearLayout.LayoutParams(-1,-2);}private void addSpace(int n){Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(n)));}private int dp(int n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}private String formatDuration(long x){return String.format(Locale.getDefault(),"%02d:%02d",x/60,x%60);}private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
