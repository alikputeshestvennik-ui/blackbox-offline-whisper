package com.blackbox.offline;

import android.app.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

/** Local chronological event history with in-app playback. */
public class HistoryActivity extends Activity {
    private static final int BG=Color.rgb(11,12,13), CARD=Color.rgb(23,25,27), TEXT=Color.rgb(247,243,238), MUTED=Color.rgb(183,177,168), ORANGE=Color.rgb(244,119,33);
    private LinearLayout list; private MediaPlayer player; private String playingId="";
    @Override public void onCreate(Bundle state){super.onCreate(state); RetentionManager.clean(this); render();}
    private void render(){
        ScrollView scroll=new ScrollView(this); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(24),dp(20),dp(30));root.setBackgroundColor(BG);scroll.addView(root);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL); Button back=small("‹ Назад");top.addView(back);TextView h=text("История событий",26,TEXT);h.setPadding(dp(12),0,0,0);top.addView(h);root.addView(top);back.setOnClickListener(v->finish());
        TextView hint=text("Фрагменты сгруппированы по дате. Нажми «Слушать», чтобы воспроизвести запись прямо здесь.",14,MUTED);hint.setPadding(0,dp(14),0,dp(18));root.addView(hint);
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(scroll);
        ArrayList<Entry> items=new EntryStore(this).all(); if(items.isEmpty()){list.addView(text("Событий пока нет. Включи авто-запись на главном экране — тишина сохраняться не будет.",16,MUTED));return;}
        String lastDay=""; for(Entry e:items){String day=dayOf(e);if(!day.equals(lastDay)){TextView group=text(day,18,ORANGE);group.setPadding(0,dp(14),0,dp(8));list.addView(group);lastDay=day;} addCard(e);}
    }
    private String dayOf(Entry e){try{return new SimpleDateFormat("EEEE, d MMMM yyyy",new Locale("ru")).format(new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(e.created));}catch(Exception x){return e.created;}}
    private String timeOf(Entry e){try{return new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(e.created));}catch(Exception x){return e.created;}}
    private void addCard(final Entry e){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(16),dp(14),dp(16),dp(14));card.setBackground(card());
        TextView time=text(timeOf(e)+"  ·  "+duration(e.duration),18,TEXT);card.addView(time);
        TextView detail=text(e.summary.isEmpty()?(e.transcript.isEmpty()?"Звуковое событие":"Расшифровка готова"):e.summary,14,MUTED);detail.setPadding(0,dp(7),0,dp(12));card.addView(detail);
        LinearLayout buttons=new LinearLayout(this);Button play=small(playingId.equals(e.id)?"■ Остановить":"▶ Слушать");Button transcribe=small(e.transcript.isEmpty()?"Расшифровать":"Текст готов");Button delete=small("Удалить");buttons.addView(play);buttons.addView(transcribe);buttons.addView(delete);card.addView(buttons);
        play.setOnClickListener(v->{if(playingId.equals(e.id))stop();else play(e);});transcribe.setOnClickListener(v->transcribe(e));delete.setOnClickListener(v->confirmDelete(e));
        LinearLayout.LayoutParams p=wide();p.setMargins(0,0,0,dp(10));list.addView(card,p);
    }
    private void transcribe(final Entry e){
        if(!e.transcript.isEmpty()){new AlertDialog.Builder(this).setTitle("Локальная расшифровка").setMessage(e.transcript).setPositiveButton("Закрыть",null).show();return;}
        File audio=new File(e.path);if(!audio.exists()){Toast.makeText(this,"Файл уже удалён",Toast.LENGTH_SHORT).show();return;}
        final AlertDialog wait=new AlertDialog.Builder(this).setTitle("Расшифровка").setMessage("Whisper обрабатывает запись локально. Не закрывай приложение.").setCancelable(false).create();wait.show();
        new Thread(()->{try{String result=new LocalAiEngine(this).transcribe(e.path);e.transcript=result;new EntryStore(this).replace(e);runOnUiThread(()->{wait.dismiss();render();Toast.makeText(this,"Расшифровка готова",Toast.LENGTH_SHORT).show();});}catch(Exception x){runOnUiThread(()->{wait.dismiss();new AlertDialog.Builder(this).setTitle("Не удалось расшифровать").setMessage(x.getMessage()).setPositiveButton("Закрыть",null).show();});}}).start();
    }
    private void play(final Entry e){try{stop();File audio=new File(e.path);if(!audio.exists()){Toast.makeText(this,"Файл уже удалён",Toast.LENGTH_SHORT).show();new EntryStore(this).delete(e.id);render();return;}player=new MediaPlayer();player.setDataSource(e.path);player.setOnCompletionListener(mp->{stop();});player.prepare();player.start();playingId=e.id;render();}catch(Exception x){Toast.makeText(this,"Не удалось воспроизвести фрагмент",Toast.LENGTH_SHORT).show();stop();}}
    private void stop(){if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}playingId="";}
    private void confirmDelete(final Entry e){new AlertDialog.Builder(this).setTitle("Удалить фрагмент?").setMessage("Будут удалены аудио и связанные локальные текстовые данные.").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{if(playingId.equals(e.id))stop();new File(e.path).delete();new EntryStore(this).delete(e.id);render();}).show();}
    @Override protected void onDestroy(){stop();super.onDestroy();}
    private String duration(long s){return String.format(Locale.getDefault(),"%02d:%02d",s/60,s%60);} private TextView text(String s,int z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);return v;}private Button small(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTextColor(TEXT);b.setAllCaps(false);b.setBackgroundColor(Color.rgb(46,49,51));return b;}private GradientDrawable card(){GradientDrawable g=new GradientDrawable();g.setColor(CARD);g.setCornerRadius(dp(17));return g;}private LinearLayout.LayoutParams wide(){return new LinearLayout.LayoutParams(-1,-2);}private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+.5f);}
}
