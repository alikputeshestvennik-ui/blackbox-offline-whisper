package com.blackbox.offline;
import android.content.*; import org.json.*; import java.util.*;
public class EntryStore {
 private final SharedPreferences p; private static final String KEY="entries_v1";
 EntryStore(Context c){p=c.getSharedPreferences("blackbox_local",Context.MODE_PRIVATE);}
 ArrayList<Entry> all(){ArrayList<Entry> r=new ArrayList<>();try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));for(int i=0;i<a.length();i++)r.add(Entry.from(a.getJSONObject(i)));}catch(Exception ignored){} return r;}
 void save(ArrayList<Entry> list){try{JSONArray a=new JSONArray();for(Entry e:list)a.put(e.json());p.edit().putString(KEY,a.toString()).apply();}catch(Exception ignored){}}
 void add(Entry e){ArrayList<Entry> a=all();a.add(0,e);save(a);}
 void replace(Entry updated){ArrayList<Entry>a=all();for(int i=0;i<a.size();i++)if(a.get(i).id.equals(updated.id)){a.set(i,updated);save(a);return;}}
 void delete(String id){ArrayList<Entry>a=all();for(Iterator<Entry>it=a.iterator();it.hasNext();)if(it.next().id.equals(id))it.remove();save(a);}
}
