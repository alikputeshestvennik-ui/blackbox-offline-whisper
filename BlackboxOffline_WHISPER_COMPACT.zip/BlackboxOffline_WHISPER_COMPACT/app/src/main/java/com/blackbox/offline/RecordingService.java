package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.Build;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Visible foreground microphone service. It retains only sound-event clips:
 * a 1.5-second pre-roll, detected sound, and a 2.5-second quiet tail.
 * Silence is continuously analysed in RAM and never persisted.
 */
public class RecordingService extends Service {
    public static final String START="com.blackbox.offline.START_RECORDING", STOP="com.blackbox.offline.STOP_RECORDING", STATE="com.blackbox.offline.RECORDING_STATE";
    private static final String CHANNEL="blackbox_recording"; private static final int NOTICE=701;
    private static final int RATE=16000, FRAME=1024, THRESHOLD=900;
    private static final long PRE_ROLL_MS=1500, TAIL_MS=2500, MAX_CLIP_MS=10*60*1000L;
    private AudioRecord mic; private Thread worker; private volatile boolean active, saving;
    private final ArrayDeque<short[]> preRoll=new ArrayDeque<>(); private int preFrames=(int)(PRE_ROLL_MS*RATE/1000/FRAME)+1;
    private ByteArrayOutputStream clip; private long clipStarted, lastLoud;

    @Override public void onCreate(){super.onCreate();createChannel();}
    @Override public int onStartCommand(Intent in,int flags,int id){String a=in==null?"":in.getAction();if(START.equals(a)&&!active)startListening();if(STOP.equals(a))stopListening();return START_NOT_STICKY;}
    private void startListening(){
        try{
            Intent stop=new Intent(this,RecordingService.class).setAction(STOP);
            PendingIntent pi=PendingIntent.getService(this,9,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification n=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("Blackbox слушает события").setContentText("Тишина не сохраняется · Нажмите «Остановить» для завершения").setOngoing(true).addAction(new Notification.Action.Builder(null,"Остановить",pi).build()).build();
            if(Build.VERSION.SDK_INT>=29)startForeground(NOTICE,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);else startForeground(NOTICE,n);
            int min=AudioRecord.getMinBufferSize(RATE,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
            mic=new AudioRecord(MediaRecorder.AudioSource.MIC,RATE,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(min,FRAME*4));
            if(mic.getState()!=AudioRecord.STATE_INITIALIZED)throw new IllegalStateException("Microphone unavailable");
            mic.startRecording();active=true;broadcast(true);worker=new Thread(this::loop,"BlackboxSoundGate");worker.start();
        }catch(Exception ignored){releaseMic();stopForeground(true);stopSelf();broadcast(false);}
    }
    private void loop(){short[] frame=new short[FRAME];while(active&&mic!=null){int got=mic.read(frame,0,frame.length);if(got<=0)continue;short[] copy=Arrays.copyOf(frame,got);int level=rms(copy);long now=System.currentTimeMillis();
        if(!saving){preRoll.addLast(copy);while(preRoll.size()>preFrames)preRoll.removeFirst();if(level>=THRESHOLD)openClip(now);}
        else {writePcm(copy);if(level>=THRESHOLD)lastLoud=now;if(now-lastLoud>=TAIL_MS||now-clipStarted>=MAX_CLIP_MS)closeClip();}
    }}
    private int rms(short[] values){long sum=0;for(short v:values)sum+=(long)v*v;return values.length==0?0:(int)Math.sqrt(sum/values.length);}
    private void openClip(long now){saving=true;clip=new ByteArrayOutputStream();for(short[] part:preRoll)writePcm(part);clipStarted=now;lastLoud=now;}
    private void writePcm(short[] values){if(clip==null)return;for(short v:values){clip.write(v&255);clip.write((v>>8)&255);}}
    private synchronized void closeClip(){if(!saving||clip==null)return;saving=false;byte[] pcm=clip.toByteArray();clip=null;preRoll.clear();if(pcm.length<FRAME*2)return;
        try{File folder=new File(getExternalFilesDir(null),"audio");if(!folder.exists())folder.mkdirs();String id=UUID.randomUUID().toString();File file=new File(folder,id+".wav");writeWav(file,pcm);long seconds=Math.max(1,pcm.length/(RATE*2));String date=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date());new EntryStore(this).add(new Entry(id,file.getAbsolutePath(),date,seconds,"",""));RetentionManager.clean(this);}catch(Exception ignored){}
    }
    private void writeWav(File file,byte[] pcm)throws IOException{try(FileOutputStream out=new FileOutputStream(file)){int size=pcm.length;out.write(new byte[]{'R','I','F','F'});le(out,36+size);out.write(new byte[]{'W','A','V','E','f','m','t',' '});le(out,16);out.write(new byte[]{1,0,1,0});le(out,RATE);le(out,RATE*2);out.write(new byte[]{2,0,16,0,'d','a','t','a'});le(out,size);out.write(pcm);}}
    private void le(OutputStream out,int n)throws IOException{out.write(n&255);out.write(n>>8&255);out.write(n>>16&255);out.write(n>>24&255);}
    private void stopListening(){active=false;if(worker!=null)try{worker.join(500);}catch(InterruptedException ignored){}closeClip();releaseMic();stopForeground(true);broadcast(false);stopSelf();}
    private void releaseMic(){if(mic!=null){try{mic.stop();}catch(Exception ignored){}mic.release();mic=null;}}
    private void broadcast(boolean on){sendBroadcast(new Intent(STATE).setPackage(getPackageName()).putExtra("active",on));}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"События Blackbox",NotificationManager.IMPORTANCE_LOW);c.setDescription("Видимое уведомление, пока Blackbox слушает локальные звуковые события");getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    @Override public android.os.IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){if(active)stopListening();else releaseMic();super.onDestroy();}
}
