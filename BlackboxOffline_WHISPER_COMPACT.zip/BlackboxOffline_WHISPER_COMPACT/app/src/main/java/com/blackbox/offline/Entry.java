package com.blackbox.offline;
import org.json.*;
public class Entry {
 public String id, path, created, transcript, summary;
 public long duration;
 Entry(String i,String p,String c,long d,String t,String s){id=i;path=p;created=c;duration=d;transcript=t;summary=s;}
 JSONObject json() throws JSONException { JSONObject o=new JSONObject(); o.put("id",id);o.put("path",path);o.put("created",created);o.put("duration",duration);o.put("transcript",transcript);o.put("summary",summary);return o; }
 static Entry from(JSONObject o){return new Entry(o.optString("id"),o.optString("path"),o.optString("created"),o.optLong("duration"),o.optString("transcript"),o.optString("summary"));}
}
