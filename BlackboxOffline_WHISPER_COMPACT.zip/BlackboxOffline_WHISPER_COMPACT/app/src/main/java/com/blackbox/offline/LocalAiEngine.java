package com.blackbox.offline;

import android.content.Context;
import java.io.File;

/** Offline Whisper bridge. No HTTP, cloud API or INTERNET permission is used. */
public class LocalAiEngine {
 private final Context app;
 private final File models;
 private static volatile boolean loaded;
 private static volatile boolean attempted;
 public LocalAiEngine(Context c){app=c.getApplicationContext();models=ModelManager.folder(app);}
 public File folder(){return models;}
 private static synchronized boolean nativeAvailable(){
  if(!attempted){attempted=true;try{System.loadLibrary("blackbox_ai");loaded=true;}catch(Throwable ignored){loaded=false;}}
  return loaded;
 }
 /** True when the native Whisper library and only the Whisper model are present. */
 public boolean whisperReady(){return ModelManager.installed(app,ModelManager.WHISPER)&&nativeAvailable();}
 /** Kept for existing UI: this Whisper-stage build reports the transcription engine state. */
 public boolean ready(){return whisperReady();}
 public String transcribe(String audioPath) throws Exception {
  if(!ModelManager.installed(app,ModelManager.WHISPER))throw new IllegalStateException("Импортируй модель Whisper в разделе «AI-модели».");
  if(!nativeAvailable())throw new IllegalStateException("Нативный Whisper-движок не собран для этого устройства.");
  float[] pcm=PcmDecoder.decode16kMono(audioPath);
  return nativeTranscribePcm(pcm,ModelManager.file(app,ModelManager.WHISPER).getAbsolutePath());
 }
 /** Qwen/llama.cpp is intentionally a separate next stage; no fake summary is returned. */
 public String summarize(String text){throw new IllegalStateException("Саммари появится после отдельного подключения Qwen.");}
 public String answer(String question,String context){throw new IllegalStateException("Вопросы к дневнику появятся после отдельного подключения Qwen.");}
 private native String nativeTranscribePcm(float[] pcm,String whisperModel);
}
