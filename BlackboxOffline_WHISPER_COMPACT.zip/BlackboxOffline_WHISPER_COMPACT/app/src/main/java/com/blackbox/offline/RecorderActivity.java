package com.blackbox.offline;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.Gravity;
import android.widget.*;

/** Launcher screen. Recording is owned by RecordingService, so screen-off does not stop it. */
public class RecorderActivity extends Activity {
 private static final int MIC=7; private Button record; private TextView state; private boolean active;
 private final BroadcastReceiver updates=new BroadcastReceiver(){public void onReceive(Context c,Intent i){active=i.getBooleanExtra("active",false); render();}};
 @Override public void onCreate(Bundle b){super.onCreate(b); RetentionManager.clean(this); registerReceiver(updates,new IntentFilter(RecordingService.STATE), Context.RECEIVER_NOT_EXPORTED); render();}
 private void render(){ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER_HORIZONTAL);box.setPadding(dp(24),dp(38),dp(24),dp(30));box.setBackgroundColor(Color.rgb(11,12,13));scroll.addView(box);
  ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.blackbox_mark);box.addView(logo,new LinearLayout.LayoutParams(dp(94),dp(94)));
  TextView name=text("Blackbox",31,Color.rgb(247,243,238));name.setGravity(Gravity.CENTER);name.setPadding(0,dp(16),0,0);box.addView(name,wide());
  TextView sub=text("Локальный аудиодневник",16,Color.rgb(183,177,168));sub.setGravity(Gravity.CENTER);box.addView(sub,wide());
  state=text(active?"● Умное прослушивание активно":"● Умное прослушивание выключено",17,active?Color.rgb(255,142,74):Color.rgb(183,177,168));state.setGravity(Gravity.CENTER);state.setPadding(dp(14),dp(18),dp(14),dp(18));state.setBackground(card());LinearLayout.LayoutParams sp=wide();sp.setMargins(0,dp(32),0,dp(12));box.addView(state,sp);
  record=button(active?"■  Остановить и сохранить":"●  Начать запись",active?Color.rgb(198,61,33):Color.rgb(244,119,33));box.addView(record,wide());record.setOnClickListener(v->toggle());
  TextView info=text(active?"Можно выключить экран или свернуть Blackbox: запись продолжится. В шторке есть кнопка «Остановить».":"Запись запускается только этой кнопкой. При записи Android показывает постоянное уведомление.",14,Color.rgb(183,177,168));info.setPadding(dp(8),dp(22),dp(8),0);box.addView(info,wide());
  Button history=button("История событий",Color.rgb(46,49,51));LinearLayout.LayoutParams hp=wide();hp.setMargins(0,dp(12),0,0);box.addView(history,hp);history.setOnClickListener(v->startActivity(new Intent(this,HistoryActivity.class)));
  Button models=button("AI-модели (офлайн)",Color.rgb(244,119,33));LinearLayout.LayoutParams mp=wide();mp.setMargins(0,dp(12),0,0);box.addView(models,mp);models.setOnClickListener(v->startActivity(new Intent(this,ModelsActivity.class)));
  Button askDiary=button("Спросить дневник",Color.rgb(46,49,51));LinearLayout.LayoutParams ap=wide();ap.setMargins(0,dp(12),0,0);box.addView(askDiary,ap);askDiary.setOnClickListener(v->startActivity(new Intent(this,AskDiaryActivity.class))); 
  TextView local=text("Скользящее хранение: 14 дней или до 5 ГБ. Удаляются сначала самые старые аудио, транскрипты и саммари вместе. У приложения нет разрешения на интернет.",13,Color.rgb(140,134,126));local.setPadding(dp(8),dp(20),dp(8),0);box.addView(local,wide());
  Button erase=button("Очистить весь дневник",Color.rgb(73,39,28));LinearLayout.LayoutParams ep=wide();ep.setMargins(0,dp(22),0,0);box.addView(erase,ep);erase.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Удалить все данные?").setMessage("Будут удалены все аудиозаписи, расшифровки и саммари только на этом телефоне.").setNegativeButton("Отмена",null).setPositiveButton("Удалить всё",(d,w)->{RetentionManager.deleteEverything(this);Toast.makeText(this,"Дневник очищен",Toast.LENGTH_SHORT).show();}).show());
  setContentView(scroll); }
 private void toggle(){if(active){startService(new Intent(this,RecordingService.class).setAction(RecordingService.STOP));}else if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)begin();else requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC);}
 private void begin(){Intent i=new Intent(this,RecordingService.class).setAction(RecordingService.START);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);active=true;render();}
 @Override public void onRequestPermissionsResult(int r,String[]p,int[]g){super.onRequestPermissionsResult(r,p,g);if(r==MIC&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)begin();}
 @Override public void onDestroy(){unregisterReceiver(updates);super.onDestroy();}
 private TextView text(String s,int z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);return v;} private Button button(String s,int c){Button b=new Button(this);b.setText(s);b.setTextSize(18);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundColor(c);b.setPadding(0,dp(12),0,dp(12));return b;}private GradientDrawable card(){GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(23,25,27));d.setCornerRadius(dp(18));return d;}private LinearLayout.LayoutParams wide(){return new LinearLayout.LayoutParams(-1,-2);}private int dp(int n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}
}
