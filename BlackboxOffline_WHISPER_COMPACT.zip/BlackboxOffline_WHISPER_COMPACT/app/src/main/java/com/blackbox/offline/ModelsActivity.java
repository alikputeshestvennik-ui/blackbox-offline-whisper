package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

/** Offline model installer. Uses Android document picker and makes no network request. */
public class ModelsActivity extends Activity {
 private static final int PICK_WHISPER=11,PICK_LLM=12,PICK_SOUNDS=13; private LinearLayout box;
 @Override public void onCreate(Bundle b){super.onCreate(b);render();}
 private void render(){ScrollView s=new ScrollView(this);box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(25),dp(22),dp(32));box.setBackgroundColor(Color.rgb(11,12,13));s.addView(box);setContentView(s);
  Button back=button("‹ Назад",Color.rgb(46,49,51));box.addView(back);back.setOnClickListener(v->finish());
  TextView title=text("Локальные AI-модели",26,Color.rgb(247,243,238));title.setPadding(0,dp(22),0,dp(8));box.addView(title);
  TextView intro=text("Выбирай файлы из Downloads. Blackbox копирует их только в своё локальное хранилище — интернет-разрешения у приложения нет.",14,Color.rgb(183,177,168));box.addView(intro);
  add("Whisper: речь → текст",ModelManager.WHISPER,"Подходит твой GGML Whisper Small (.bin). После импорта Blackbox хранит его локально как whisper.bin.",PICK_WHISPER);
  add("Саммари, теги и вопросы",ModelManager.LLM,"Подходит Qwen 2.5 3B Instruct в GGUF. Ожидаемое имя после импорта: qwen2.5-3b-q4.gguf.",PICK_LLM);
  add("Сирены и звуковые события",ModelManager.SOUNDS,"Необязательная TFLite-модель классификации звуков. Без неё сохраняются все нетихие события, но без точных категорий.",PICK_SOUNDS);
  TextView note=text("Важно: импорт моделей подготовит файлы. Для реальной расшифровки и генерации в APK также должен быть подключён нативный движок arm64-v8a (whisper.cpp / llama.cpp).",14,Color.rgb(255,185,105));note.setPadding(0,dp(22),0,0);box.addView(note);
 }
 private void add(String title,String name,String desc,int request){TextView h=text(title,22,Color.rgb(247,243,238));h.setPadding(0,dp(25),0,dp(6));box.addView(h);TextView d=text(desc,14,Color.rgb(183,177,168));box.addView(d);TextView stat=text("Статус: "+ModelManager.size(this,name),14,Color.rgb(244,119,33));stat.setPadding(0,dp(8),0,dp(8));box.addView(stat);Button b=button("Импортировать файл",Color.rgb(244,119,33));box.addView(b);b.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/octet-stream");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,request);});}
 @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(c!=RESULT_OK||data==null||data.getData()==null)return;String target=r==PICK_WHISPER?ModelManager.WHISPER:r==PICK_LLM?ModelManager.LLM:r==PICK_SOUNDS?ModelManager.SOUNDS:null;if(target==null)return;Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}new Thread(()->{try{ModelManager.importFile(this,uri,target);runOnUiThread(()->{Toast.makeText(this,"Модель импортирована",Toast.LENGTH_SHORT).show();render();});}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Ошибка импорта: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
 private TextView text(String x,int z,int c){TextView v=new TextView(this);v.setText(x);v.setTextColor(c);v.setTextSize(z);return v;}private Button button(String x,int c){Button b=new Button(this);b.setText(x);b.setTextColor(Color.WHITE);b.setTextSize(16);b.setAllCaps(false);b.setBackgroundColor(c);return b;}private int dp(int n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}
}
