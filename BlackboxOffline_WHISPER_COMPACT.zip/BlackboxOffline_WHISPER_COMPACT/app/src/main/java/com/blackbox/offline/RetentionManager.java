package com.blackbox.offline;

import android.content.Context;
import java.io.File;
import java.util.*;

/** Keeps a rolling local journal: latest 14 days, capped at 5 GiB. */
public final class RetentionManager {
    public static final int DAYS_TO_KEEP = 14;
    public static final long MAX_BYTES = 5L * 1024L * 1024L * 1024L;
    private RetentionManager() { }

    /** Deletes old entries, then oldest remaining entries until the storage cap is met.
     *  Each removal deletes the audio file and its text metadata together. */
    public static int clean(Context context) {
        EntryStore store = new EntryStore(context);
        ArrayList<Entry> entries = store.all();
        long cutoff = System.currentTimeMillis() - DAYS_TO_KEEP * 24L * 60L * 60L * 1000L;
        ArrayList<Entry> keep = new ArrayList<>();
        int removed = 0;

        for (Entry entry : entries) {
            File audio = new File(entry.path);
            if (!audio.exists() || audio.lastModified() < cutoff) {
                if (audio.exists()) audio.delete();
                removed++;
            } else {
                keep.add(entry);
            }
        }

        Collections.sort(keep, new Comparator<Entry>() {
            @Override public int compare(Entry a, Entry b) {
                return Long.compare(new File(a.path).lastModified(), new File(b.path).lastModified());
            }
        });
        long total = 0L;
        for (Entry entry : keep) total += new File(entry.path).length();
        while (total > MAX_BYTES && !keep.isEmpty()) {
            Entry oldest = keep.remove(0);
            File audio = new File(oldest.path);
            total -= audio.length();
            if (audio.exists()) audio.delete();
            removed++;
        }
        store.save(keep);
        return removed;
    }

    /** Explicit full erase: audio and all local transcript/summary metadata. */
    public static void deleteEverything(Context context) {
        EntryStore store = new EntryStore(context);
        for (Entry entry : store.all()) new File(entry.path).delete();
        store.save(new ArrayList<Entry>());
        File audioFolder = new File(context.getExternalFilesDir(null), "audio");
        File[] leftovers = audioFolder.listFiles();
        if (leftovers != null) for (File file : leftovers) file.delete();
    }
}
